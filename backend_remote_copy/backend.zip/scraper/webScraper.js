/**
 * webScraper.js
 * --------------------------------------------------
 * Scrapea sitios web con Puppeteer para extraer:
 * - Título, descripción, imagen OG
 * - Enlaces de redes sociales (Facebook, Instagram, X/Twitter, TikTok, YouTube, LinkedIn)
 * - Llama automáticamente a rssCollector.js para recolectar artículos RSS del dominio
 */

const puppeteer = require("puppeteer");
const socialScraper = require("./socialScraper");
const { collectRSS } = require("../rss/rssCollector");

/**
 * Scrape a website and extract metadata + social links + RSS
 * @param {string} url
 * @returns {Object} Extracted data
 */
async function webScraper(url) {
  let browser;
  try {
    browser = await puppeteer.launch({
      headless: true,
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-gpu",
        "--no-zygote",
      ],
    });

    const page = await browser.newPage();

    await page.setUserAgent(
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
      "(KHTML, like Gecko) Chrome/115.0 Safari/537.36"
    );

    console.log(`🌐 Scraping website: ${url}`);
    await page.goto(url, { waitUntil: "networkidle2", timeout: 60000 });

    // Extract metadata
    const title = await page.title();
    const description = await page.$eval("meta[name='description']", el => el.content).catch(() => "");
    const ogImage = await page.$eval("meta[property='og:image']", el => el.content).catch(() => "");

    // Extract and normalize links
    const allLinks = await page.$$eval("a", links => links.map(l => l.href.trim()).filter(Boolean));
    const baseUrl = new URL(url).origin;

    const cleanLinks = allLinks.map(link => {
      if (link.startsWith("//")) return "https:" + link;
      if (link.startsWith("/")) return baseUrl + link;
      return link;
    });

    // Identify social media links
    const socialDomains = [
      "facebook.com",
      "instagram.com",
      "twitter.com",
      "x.com",
      "tiktok.com",
      "linkedin.com",
      "youtube.com",
      "youtu.be",
    ];

    const socialLinks = [
      ...new Set(cleanLinks.filter(link => socialDomains.some(domain => link.includes(domain)))),
    ];

    console.log(`🔗 Found ${socialLinks.length} social media links`);

    // Scrape social profiles for deeper data
    let socialData = {};
    if (socialLinks.length > 0) {
      console.log("🕵️ Fetching details from social profiles...");
      socialData = await socialScraper(socialLinks, browser);
    }

    // 🔍 Detect RSS feeds and collect articles
    const domain = new URL(url).origin;
    console.log(`📰 Checking for RSS feeds at ${domain}...`);
    const rssArticles = await collectRSS(domain);

    await browser.close();

    // Final combined result
    const result = {
      url,
      title,
      description,
      ogImage,
      socialLinks,
      socialData,
      rss: rssArticles || [],
    };

    console.log(`✅ Finished scraping: ${url}`);
    return result;

  } catch (error) {
    if (browser) await browser.close();
    console.error("❌ Error scraping website:", error.message);
    return { error: "Failed to scrape the website." };
  }
}

module.exports = webScraper;
