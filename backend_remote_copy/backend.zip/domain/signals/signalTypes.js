module.exports = {
  PRESENCE: "presence",
  ACTIVITY: "activity",
  AUDIENCE: "audience",
  ENGAGEMENT: "engagement",
  CONSISTENCY: "consistency"
};
